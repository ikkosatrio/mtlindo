<?php $__env->startSection('content'); ?>
<!--breadcrumb-->
<style type="text/css" media="screen">
    .header-breadcrumb {
        background: url(<?php echo e(img_header($header->potensi)); ?>) no-repeat scroll center 0 transparent;
        -webkit-background-size: cover;
        background-size: cover;
    }
</style>
<section class="row header-breadcrumb sectpad">
    <div class="container">
        <div class="row m0 page-cover">
            <h2 class="page-cover-tittle">Potensi</h2>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(base_url()); ?>">Home</a></li>
            <li class="active">Potensi</li>
        </ol>
        </div>
    </div>
</section>


<!--checkout-->
<section class="row check-project sectpad">
    <div class="container">
        <div class="row m0 section_header color">
            <h2>Checkout Our Projects</h2>
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium dolore mque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dict eaque ipsa quae ab illo inventore veritatis et quasi architecto.</p>
        </div>        
    </div>
</section>

<!-- Projects -->
<section class="row latest_projects sectpad projects-3">
    <div class="container">
        
        <div class="projects3 row m0" id="projects">
            <div class="grid-sizer"></div>
            <?php $__currentLoopData = $potensiBaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="project project-listing project-item indoor wood_supply hardwood manufacturing">
                <div class="projects-img col-md-7 col-lg-8">
                    <div class="projects-img-hover">
                        <img style="max-width: 770px;max-height: 327px;min-height: 327px" src="<?php echo e(img_potensi($result->cover)); ?>" alt="<?php echo e($result->judul); ?>">
                    </div>
                    <a href="<?php echo e(base_url('main/potensi/'.$result->id_potensi.'/'.seo($result->judul))); ?>" class="projects-button">Details</a>
                </div>                
                <div class="projects-content">
                    <a href="<?php echo e(base_url('main/potensi/'.$result->id_potensi.'/'.seo($result->judul))); ?>"><h3><?php echo e($result->judul); ?></h3></a>
                    <p><?php echo read_more($result->deskripsi,200); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>