<?php $__env->startSection('content'); ?>
<!--breadcrumb-->
<?php $__env->startSection('css'); ?>
<style type="text/css" media="screen">
    .header-breadcrumb {
        background: url(<?php echo e(img_header($header->profil)); ?>) no-repeat scroll center 0 transparent;
        -webkit-background-size: cover;
        background-size: cover;
    }
    .who-area {
        background: url('') no-repeat scroll center 0 transparent;
        position: relative!important;
    }
    .who-area .who-are-image:after{
             border: 0px solid #fff;
    }
</style>
<?php $__env->stopSection(); ?>
<section class="row header-breadcrumb">
    <div class="container">
            <div class="row m0 page-cover">
                <h2 class="page-cover-tittle">Profil</h2>
            <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li class="active">Profil</li>
            </ol>
            </div>
        </div>
</section>

<!--who-are-->
<section class=" row who-area sectpad">
    <div class="container">
        <div class="row m0 section_header color">
            <h2>Apa sih <?php echo e($profil->nama_desa); ?>?</h2>
        </div>
        <div class="row">
            <div class="col-sm-4 col-lg-3 who-are">
                <div class="who-are-image row m0">
                    <img src="<?php echo e(img_profil($profil->gambar)); ?>" alt="<?php echo e($profil->nama_desa); ?>">
                </div>
            </div>
            <div class="col-sm-8 col-lg-9 who-are-texts">
                <div class="who-text">
                    <h3><?php echo e($profil->nama_desa); ?></h3>
                    <p><?php echo $profil->deskripsi; ?></p>
                </div>
            </div>
        </div>
    </div>
</section>
<!--features-->

<!--team-->



<!--testimonial-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>