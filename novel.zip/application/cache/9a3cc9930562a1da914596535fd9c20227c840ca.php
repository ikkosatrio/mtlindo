<?php $__env->startSection('content'); ?>
<!--breadcrumb-->
<style type="text/css" media="screen">
    .header-breadcrumb {
        background: url(<?php echo e(img_header($header->produk)); ?>) no-repeat scroll center 0 transparent;
        -webkit-background-size: cover;
        background-size: cover;
    }
</style>
<section class="row header-breadcrumb sectpad">
    <div class="container">
        <div class="row m0 page-cover">
            
        <ol class="breadcrumb">
            <li><a href="index.html">Home</a></li>
            <li class="active"><?php echo e(read_more($produk->judul,30)); ?>...</li>
        </ol>
        </div>
    </div>
</section>




<!--blog-details-->
<section class="row blog_content">
    <div class="container">
        <div class="row sectpad">
            <div class="blog_section col-lg-8 shop-page-content product-page">
                <div class="row product-details-box">
                    <div class="col-lg-6 img-holder">
                        <img style="max-width: 370px;max-height: 426px;min-height: 426px" src="<?php echo e(img_produk($produk->cover)); ?>" alt="">
                    </div>
                    <div class="col-lg-6">
                        <h3><?php echo e($produk->judul); ?></h3>
                        <h4>Harga Rp. <?php echo e(number_format($produk->harga)); ?></h4>
                            <?php echo $produk->deskripsi; ?>

                        <span>Dilihat : <b><?php echo e($produk->view); ?></b></span>
                    </div>
                </div>

                
                

                <div class="row best-seller">
                    <div class="row m0 section_header color">
                        <h2>Produk Terkait</h2>
                    </div>
                </div>
                <br><br>
                <div class="row">
                    <!--Start single shop item-->
                    <?php $__currentLoopData = $produkRand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 single-shop-item">
                        <img style="max-width: 244px;max-height: 190px;min-height: 190px" src="<?php echo e(img_produk($result->cover)); ?>" alt="">
                        <div class="meta">
                            <h4><?php echo e($result->judul); ?></h4>
                            <span>Harga: <b>Rp. <?php echo e(number_format($produk->harga)); ?></b></span>
                            <a href="<?php echo e(base_url('main/produk/'.$result->id_produk.'/'.seo($result->judul))); ?>">
                                <div class="cart-button">
                                    <p>DETAIL PRODUK</p>
                                    <i class="fa fa-eye"></i>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php if($key==3): ?>
                        <?php break; ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--End single shop item-->
                </div>

            </div>
            <div class="sidebar_section col-lg-4">
                <div class="sidebar row m0">
                    <div class="row widget widget-search">
                        <div class="row widget-inner">
                            <form action="<?php echo e(base_url('main/produk/cari')); ?>" class="search-form" method="post">
                                <div class="input-group">
                                    <input type="search" name="cari" class="form-control" placeholder="Cari Produk">
                                    <span class="input-group-addon">
                                        <button type="submit"><i class="icon icon-Search"></i></button>
                                    </span>
                                </div>
                            </form>
                        </div>
                    </div> <!--Search-->
                    <div class="row widget widget-popular-posts">
                        <h4 class="widget-title">Populer Produk</h4>
                        <div class="row widget-inner">
                            <?php $__currentLoopData = $produkPop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media popular-post">
                                <div class="media-left"><a href="<?php echo e(base_url('main/produk/'.$result->id_produk.'/'.seo($result->judul))); ?>"><img style="max-width: 120px;max-height: 92px;min-height: 92px" src="<?php echo e(img_produk($result->cover)); ?>" alt=""></a></div>
                                <div class="media-body">
                                    <h5 class="post-title"><a href="<?php echo e(base_url('main/produk/'.$result->id_produk.'/'.seo($result->judul))); ?>"><?php echo e($result->judul); ?></a></h5>
                                    <h5 class="post-date"><a href="<?php echo e(base_url('main/produk/'.$result->id_produk.'/'.seo($result->judul))); ?>"><?php echo e(tgl_indo($result->created_at)); ?></a></h5>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div> <!--Popular Posts-->
                    
                    
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>