<?php $__env->startSection('content'); ?>
<!--rv-slider-->
<section class="bannercontainer row">
    <div class="rev_slider banner row m0" id="rev_slider" data-version="5.0">
        <ul>
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-transition="slidehorizontal"  data-delay="10000">
                <img style="max-width: 1920px;max-height: 828px;min-height: 828px" src="<?php echo e(img_slider($result->cover)); ?>"  alt="" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >
                <div class="tp-caption sfr tp-resizeme carpenters-h1" 
                    data-x="0" data-hoffset="690" 
                    data-y="355" data-voffset="160" 
                    data-whitespace="nowrap"
                    data-start="900">
                    <?php echo e($result->judul); ?>


                </div>
                <div class="tp-caption sfb tp-resizeme carpenters-p" 
                    data-x="0" data-hoffset="500" 
                    data-y="430" data-voffset="470" 
                    data-whitespace="nowrap"
                    data-start="1800">                    
                    <?php echo $result->deskripsi; ?>

                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
        </ul>
    </div>
</section>

<section class="row experience-area">
   <div class="container">
       <div class="row">
           <div class="col-sm-5 worker-image">
               <img style="max-width: 336px;max-height: 366px;min-height: 366px" src="<?php echo e(img_profil($profil->gambar)); ?>" alt="<?php echo e($profil->nama_desa); ?>">
           </div>
           <div class="col-sm-7 experience-info">
              <div class="content">
                  <h2><?php echo e($profil->nama_desa); ?></h2> 
                  <p><?php echo $profil->deskripsi; ?></p>  
              </div>
              
               
           </div>
       </div>
   </div>
</section>


<!--we-do-->
<section class="row sectpad we-do-section">
    <div class="container">
        <div class="row m0 section_header color">
           <h2>Artikel Terbaru</h2> 
        </div>
        <div class="we-do-slider">
            <div class="we-sliders">
                <?php $__currentLoopData = $artikelBaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="post-image">
                        <img style="min-height: 200px" src="<?php echo e(img_artikel($result->cover)); ?>"  alt="">
                    </div>
                    <a href="<?php echo e(base_url('main/artikel/'.$result->id_artikel.'/'.seo($result->judul))); ?>"><h4><?php echo e(ucwords($result->judul)); ?></h4></a>
                    <p><?php echo e(read_more($result->deskripsi,150)); ?>...</p>
                </div>
                <?php if($key==7): ?>
                    <?php break; ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>

<!-- Projects -->
<section class="row latest_projects sectpad projects-1">
    <div class="container">
        <div class="row m0 section_header">
            <h2>Gallery</h2>
        </div>
        <div class="row m0 filter_row">
            <ul class="nav project_filter" id="project_filter2">
                <li class="active" data-filter="*">all</li>
                <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($element->id_album==$result->id_album): ?>
                            <li data-filter=".<?php echo e($result->id_album); ?>"><?php echo e($result->nama_album); ?></li>
                            <?php break; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="projects2 popup-gallery" id="projects">
            <div class="grid-sizer"></div>
            <?php $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3 col-xs-6 project <?php echo e($result->id_album); ?>">
                <div class="project-img">
                    <img style="max-width: 285px;max-height: 260px;min-height: 260px" src="<?php echo e(img_album($result->gambar)); ?>" alt="<?php echo e($result->nama_album); ?>">
                    <div class="project-text">
                        <ul class="list-unstyled">
                            <li><a href="<?php echo e(img_album($result->gambar)); ?>" data-source="#" title="<?php echo e($result->nama_album); ?>" data-desc="" class="popup"><i class="icon icon-Search"></i></a></li>
                        </ul>
                        <div class="row m0">
                            <a href="#"><h3><?php echo e($result->nama_album); ?></h3></a>
                            <p><?php echo e(tgl_indo($result->created_at)); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!--work-shop-->

<!--testimonial-->
<section class="row sectpad testimonial-area">
   <div class="container">
       <div class="row m0 section_header common">
           <h2>Potensi</h2> 
        </div>
        <div class="testimonial-sliders">
            <?php $__currentLoopData = $potensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <div class="media testimonial">
                    <div class="media-left">
                        <a href="<?php echo e(base_url('main/potensi/'.$result->id_potensi.'/'.seo($result->judul))); ?>">
                            <img style="max-width: 170px;max-height: 185px;min-height: 185px" src="<?php echo e(img_potensi($result->cover)); ?>"  alt="<?php echo e($result->judul); ?>">
                        </a>
                    </div>
                    <div class="media-body">
                        <p><?php echo e(read_more($result->deskripsi,150)); ?>...</p>
                        <a href="<?php echo e(base_url('main/potensi/'.$result->id_potensi.'/'.seo($result->judul))); ?>">-  <?php echo e($result->judul); ?></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
   </div>
</section>

<!-- latest-news-area -->
<section class="row sectpad latest-news-area">
    <div class="container">
        <div class="row m0 section_header">
           <h2>Artikel Populer</h2> 
        </div>
        <div class="row latest-content">
            <?php $__currentLoopData = $artikelPop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-4 clo-xs-12 latest">
                <div class="row m0 latest-image">
                    <a href="<?php echo e(base_url('main/artikel/'.$result->id_artikel.'/'.seo($result->judul))); ?>"><img style="max-width: 369px;max-height: 202px;min-height: 202px" src="<?php echo e(img_artikel($result->cover)); ?>" alt="<?php echo e(seo($result->judul)); ?>"></a>
                </div>
                <div class="latest-news-text">
                    <a href="<?php echo e(base_url('main/artikel/'.$result->id_artikel.'/'.seo($result->judul))); ?>">
                        <h4><?php echo e(ucwords($result->judul)); ?></h4>
                    </a>
                    <p><?php echo e(read_more($result->deskripsi,150)); ?>...</p>
                    <div class="row m0 latest-meta">
                        <a href="<?php echo e(base_url()); ?>assets/main/#"><i class="fa fa-tag"></i><?php echo e($result->nama); ?></a> <a class="read_more" href="<?php echo e(base_url()); ?>assets/main/single.html"><i class="fa fa-eye"></i> Dilihat: <?php echo e($result->view); ?></a>
                    </div>
                </div>
            </div> 
                <?php if($key==7): ?>
                    <?php break; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<!-- clients -->
<section class="row clients">
    <div class="container">
        <div class="row m0 section_header">
            <h2>Produk Desa</h2>
        </div>
        <div class="row clients-logos">
        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-2 col-sm-3 col-xs-6 client">
                <div class="row m0 inner-logo">
                   <a href="<?php echo e(base_url('main/produk/'.$result->id_produk.'/'.seo($result->judul))); ?>"><img src="<?php echo e(img_produk($result->cover)); ?>" alt="<?php echo e($result->judul); ?>"></a>
                </div>
            </div>
        <?php if($key==6): ?>
            <?php break; ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>