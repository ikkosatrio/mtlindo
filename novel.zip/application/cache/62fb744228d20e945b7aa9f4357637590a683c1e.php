<?php $__env->startSection('content'); ?>
<!--breadcrumb-->
<style type="text/css" media="screen">
    .header-breadcrumb {
        background: url(<?php echo e(img_header($header->artikel)); ?>) no-repeat scroll center 0 transparent;
        -webkit-background-size: cover;
        background-size: cover;
    }
</style>
<section class="row header-breadcrumb">
    <div class="container">
        <div class="row m0 page-cover">
            <h2 class="page-cover-tittle">Artikel</h2>
            <ol class="breadcrumb">
                <li><a href="index.html">Home</a></li>
                <li class="active">Artikel</li>
            </ol>
        </div>
    </div>
</section>


<!--blog-details-->
<section class="row blog_content">
    <div class="container">
        <div class="row sectpad">
            <div class="blog_section col-lg-8">
                <!--Blog-->
                <?php $__currentLoopData = $artikelBaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row blog">
                    <div class="featured_img row m0">
                        <a href="<?php echo e(base_url('main/artikel/'.$result->id_artikel.'/'.seo($result->judul))); ?>"><img style="max-width: 770px;max-height: 330px;min-height: 330px" src="<?php echo e(img_artikel($result->cover)); ?>" alt="" class="img-responsive"></a>
                    </div>
                    <div class="post-contents row m0">
                        <a href="<?php echo e(base_url('main/artikel/'.$result->id_artikel.'/'.seo($result->judul))); ?>" class="post-date"><?php echo e($result->view); ?><span>Dilihat</span></a>
                        <h4 class="post-title"><a href="<?php echo e(base_url('main/artikel/'.$result->id_artikel.'/'.seo($result->judul))); ?>"><?php echo e(ucwords($result->judul)); ?></a></h4>
                        <ul class="post-meta nav">
                            <li><i class="fa fa-user"></i>By: <a href="#">Admin</a></li>
                            <li><i class="fa fa-tag"></i><a href="#"><?php echo e($result->nama); ?></a></li>
                            <li><i class="fa fa-calendar"></i>Publish: <a href="#"><?php echo e(tgl_indo($result->created_at)); ?></a></li>
                        </ul>
                        <p><?php echo e(read_more($result->deskripsi,250)); ?>...</p>
                        <a href="<?php echo e(base_url('main/artikel/'.$result->id_artikel.'/'.seo($result->judul))); ?>" class="read-more submit">read more</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <ul class="pagination">
                    <li class="active"><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li class="next"><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
                </ul>
            </div>
            <div class="sidebar_section col-lg-4">
                <div class="sidebar row m0">
                    <div class="row widget widget-search">
                        <div class="row widget-inner">
                            <form action="<?php echo e(base_url('main/artikel/cari')); ?>" class="search-form" method="post">
                                <div class="input-group">
                                    <input type="search" name="cari" class="form-control" placeholder="Cari Artikel">
                                    <span class="input-group-addon">
                                        <button type="submit"><i class="icon icon-Search"></i></button>
                                    </span>
                                </div>
                            </form>
                        </div>
                    </div> <!--Search-->
                    <div class="row widget widget-categories">
                        <h4 class="widget-title">Kategori</h4>
                        <div class="row widget-inner">
                            <ul class="nav categories">
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(base_url('main/artikel/kategori/'.$result->id_kategori.'/'.seo($result->nama))); ?>"><i class="fa fa-angle-right"></i><?php echo e($result->nama); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div> <!--Categories-->
                    <div class="row widget widget-popular-posts">
                        <h4 class="widget-title">Artikel Populer</h4>
                        <div class="row widget-inner">
                        <?php $__currentLoopData = $artikelPop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media popular-post">
                                <div class="media-left"><a href="#"><img style="max-width: 120px;max-height: 92px;min-height: 92px" src="<?php echo e(img_artikel($result->cover)); ?>" alt=""></a></div>
                                <div class="media-body">
                                    <h5 class="post-title"><a href="<?php echo e(base_url('main/artikel/'.$result->id_artikel.'/'.seo($result->judul))); ?>"><?php echo e($result->judul); ?></a></h5>
                                    <h5 class="post-date"><a href="#"><?php echo e(tgl_indo($result->created_at)); ?></a></h5>
                                </div>
                            </div> <!--Popular Post-->
                        <?php if($key==5): ?>
                            <?php break; ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div> <!--Popular Posts-->
                    
                     <!--Tag Clouds-->
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>